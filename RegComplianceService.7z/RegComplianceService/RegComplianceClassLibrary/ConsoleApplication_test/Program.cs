﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RegComplianceClassLibrary;

namespace ConsoleApplication_test
{
    class Program
    {
        static void Main(string[] args)
        {
            string abc=DateTime.Now.ToString("dd/MMM/yyyy T-HH:mm:ss");
            //DateTime dt=DateTime.UtcNow.AddHours(5).AddMinutes(30);

            //DateTime modify = dt.AddMonths(1);

            RegComplianceClass.RegCompMainFuncAllData();
        }
    }
}
