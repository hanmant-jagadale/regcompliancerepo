﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace RegComplianceClassLibrary
{
    public class ConnectionDB
    {
        public static string getConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["RegComplianceEntities"].ToString();
        }

        public static string update_auto_delayed_status_events()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(getConnectionString()))
                {
                    connection.Open();
                    string status_update_query = " BEGIN "
                        //+ " update  " + GlobalVarsConfiguration.Global_EventDetail + "  set EventDetailDelayedStatus='Delayed', EventDetailModifiedBy='" + login_user_name + "', EventDetailModifiedTimestamp='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where FORMAT(EventDetailTargetDate,'yyyy-MM-dd')<FORMAT(Cast('" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' as datetime),'yyyy-MM-dd') "
                                             + " update  [dbo].[EventDetail]  set EventDetailDelayedStatus='Delayed', EventDetailModifiedBy='Windows Service', EventDetailModifiedTimestamp='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where EventDetailStatus<>'Closed' and convert(varchar(10),cast(EventDetailTargetDate as datetime),101)<convert(varchar(10),Cast('" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' as datetime),101) "
                                             + " END ";

                    using (SqlCommand command = new SqlCommand(status_update_query))
                    {
                        command.Connection = connection;
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                    return "Success";
                }
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Invoking update_auto_delayed_status_events- " + ex);
                return "Error";
            }
        }

        public static DataTable getAllHolidaysDetail()
        {
            DataTable dt = new DataTable();
            try
            {
                Utility.LogText("Invoking getAllHolidaysDetail");
                try
                {
                    string query = "select HolidayId, isnull(CONVERT(VARCHAR,HolidayDate, 103),'') as HolidayDate, HolidayYear from HolidayDetail WHERE HolidayFlag<>'False' and HolidayYear='" + DateTime.UtcNow.AddHours(5).AddMinutes(30).ToString("yyyy") + "'";
                    dt = SelectDataInDataTable(query);
                    if (dt.Rows.Count > 0)
                    {
                        Utility.LogText(string.Format("getAllHolidaysDetail - Returning DataTable rowcount:{0}", dt.Rows.Count));
                    }
                    else
                    {
                        Utility.LogText("getAllHolidaysDetail- Returning null DataTable");
                    }
                }
                catch (Exception ex)
                {
                    Utility.LogText("getAllHolidaysDetail- Returning [] ");
                }
            }
            catch (Exception e)
            {
                Utility.LogText("Error Invoking getAllHolidaysDetail" + e);
            }
            return dt;
        }

        public static DataTable getAllTaskDetail()
        {
            DataTable dt = new DataTable();
            try
            {
                Utility.LogText("Invoking getAllTaskDetail");
                try
                {
                    string query = "select "
                                    + "isnull(TaskDetailTaskMasterId,tskMaster.TaskMasterId) as TaskMasterId, "
                                    + "isnull((select TaskMasterTaskName from  [dbo].[TaskMaster]   as tMaster where tMaster.TaskMasterId=tskdtl.TaskDetailTaskMasterId),tskMaster.TaskMasterTaskName) as TaskMasterName, "
                                    + "isnull((select TaskMasterPriority from [dbo].[TaskMaster] as tMaster where tMaster.TaskMasterId=tskdtl.TaskDetailTaskMasterId),tskMaster.TaskMasterPriority) as TaskMasterPriority, "
                                    + "isnull((select TaskMasterSchedule from [dbo].[TaskMaster] as tMaster where tMaster.TaskMasterId=tskdtl.TaskDetailTaskMasterId),tskMaster.TaskMasterSchedule) as TaskMasterSchedule, "
                                    + "isnull(CONVERT(VARCHAR,tskMaster.TaskMasterTargetDate, 103),'') as TaskMasterTargetDate, "

                                    + "isnull(TaskDetailId,0) as TaskDetailId, "
                                    + "isnull(TaskDetailUserId,0) as TaskDetailUserId, "
                                    + "isnull((select UserName from [dbo].[Users] as usrs where usrs.UserId=tskdtl.TaskDetailUserId),'') as TaskDetailUserName, "
                                    + "isnull((select UserEmail from [dbo].[Users] as usrs where usrs.UserId=tskdtl.TaskDetailUserId),'') as TaskDetailUserEmail, "
                                    + "isnull(TaskDetailAssignee,0) as TaskDetailAssignee, "
                                    + "isnull((select UserName from [dbo].[Users] as usrs where usrs.UserId=tskdtl.TaskDetailAssignee),'') as TaskDetailAssigneeName, "
                                    + "isnull(CONVERT(VARCHAR,tskdtl.TaskDetailTargetDate, 103),'') as TaskDetailTargetDate "
                                    + "from [dbo].[TaskMaster] as tskMaster right join [dbo].[TaskDetail] as tskDtl  on tskMaster.TaskMasterId=tskDtl.TaskDetailTaskMasterId "
                                    + "WHERE tskMaster.TaskMasterFlag<>'False' ";
                    //Utility.LogText(query);
                    dt = SelectDataInDataTable(query);
                    if (dt.Rows.Count > 0)
                    {
                        Utility.LogText(string.Format("getAllTaskDetail - Returning DataTable rowcount:{0}", dt.Rows.Count));
                    }
                    else
                    {
                        Utility.LogText("getAllTaskDetail- Returning null DataTable");
                    }
                }
                catch (Exception ex)
                {
                    Utility.LogText("getAllTaskDetail- Returning [] ");
                }
            }
            catch (Exception e)
            {
                Utility.LogText("Error Invoking getAllTaskDetail" + e);
            }
            return dt;
        }

        public static string updateTaskDetail(DateTime dtNew, string TaskDetailId)
        {
            string strReturn = "";

            try
            {
                Utility.LogText("Invoking updateTaskDetail");
                try
                {
                    using (SqlConnection connection = new SqlConnection(getConnectionString()))
                    {
                        connection.Open();
                        string status_update_query = "BEGIN "
                                                 + "update  [dbo].[TaskDetail]  set TaskDetailTargetDate='" + dtNew.ToString("yyyy-MM-dd HH:mm:ss") + "', TaskDetailModifiedBy='Windows Service', TaskDetailModifiedTimeStamp='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where TaskDetailId='" + TaskDetailId + "' "
                                                 + "END ";

                        using (SqlCommand command = new SqlCommand(status_update_query))
                        {
                            command.Connection = connection;
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                        strReturn = "Success";
                    }
                }
                catch (Exception ex)
                {
                    strReturn = "Error";
                    Utility.LogText("updateTaskDetail- Returning [] ");
                }
            }
            catch (Exception e)
            {
                strReturn = "Error";
                Utility.LogText("Error Invoking updateTaskDetail" + e);
            }
            return strReturn;
        }

        public static string createEventToUser(string EventDetailTaskDetailId, string EventDetailUserId, DateTime dtNew, DataRow Dr)
        {
            string strReturn = "";

            try
            {
                Utility.LogText("Invoking createEventToUser");
                try
                {
                    using (SqlConnection connection = new SqlConnection(getConnectionString()))
                    {
                        connection.Open();

                        string query = " BEGIN "
                                         + " insert into [dbo].[EventDetail] (EventDetailTaskDetailId, EventDetailUserId, EventDetailTargetDate, EventDetailStatus, EventDetailApprovedStatus ,EventDetailPenalty,EventDetailCreatedTimeStamp,EventDetailCreatedBy,EventDetailFlag) "
                                         + " values (" + EventDetailTaskDetailId + ", " + EventDetailUserId + ",'" + dtNew.ToString("yyyy-MM-dd HH:mm:ss") + "', 'Not Yet Started','','','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','Windows Service', 'True'); SELECT CAST(SCOPE_IDENTITY() as int); "
                                     + " END ";

                        using (SqlCommand command = new SqlCommand(query))
                        {
                            command.Connection = connection;

                            int i = (int)command.ExecuteScalar();

                            if (i > 0)
                            {
                                strReturn = "Success";
                            }
                            else
                            {
                                strReturn = "Error";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    strReturn = "Error";
                    Utility.LogText("createEventToUser- Returning [] ");
                }
            }
            catch (Exception e)
            {
                strReturn = "Error";
                Utility.LogText("Error Invoking createEventToUser" + e);
            }

            //Send Mail to User and Assignee
            try
            {
                if (strReturn == "Success")
                {
                    string taskName = string.Empty;
                    string taskUsername = string.Empty, taskUserEmail = string.Empty;
                    string taskAssigneeName = string.Empty, taskAssigneeEmail = string.Empty;
                    string taskPriority = string.Empty, taskTargetDate = string.Empty;
                    string taskSchedule = string.Empty;

                    taskName = Dr["TaskMasterName"].ToString();
                    taskUserEmail = Dr["TaskDetailUserEmail"].ToString();
                    taskAssigneeName = Dr["TaskDetailAssigneeName"].ToString();
                    //task_detail_assigneeemail = Dr["AssigneeEmail"].ToString();
                    taskPriority = Dr["TaskMasterPriority"].ToString();
                    taskSchedule = Dr["TaskMasterSchedule"].ToString();
                    taskTargetDate = Dr["TaskMasterTargetDate"].ToString();

                    try
                    {
                        //string to_email = string.Join(",", task_detail_useremail, task_detail_assigneeemail);
                        string to_email = taskUserEmail;

                        string msg_body = "<b>Hello,</b><br/><br/> You have assign task. Details are below. <br/><br/>"
                                    + "<table>"
                                    + "      <tr>"
                                    + "       <td><b>Task Name :</b></td>"
                                    + "       <td>" + taskName.ToString().Trim() + "</td>"
                                    + "     </tr>"
                                    + "     <tr>"
                                    + "       <td><b>Supervisor :</b></td>"
                                    + "       <td>" + taskAssigneeName.ToString().Trim() + "</td>"
                                    + "    </tr> "
                                        + "     <tr>"
                                    + "       <td><b>Priority :</b></td>"
                                    + "       <td>" + taskPriority.ToString().Trim() + "</td>"
                                    + "    </tr> "
                                        + "     <tr>"
                                    + "       <td><b>Schedule :</b></td>"
                                    + "       <td>" + taskSchedule.ToString().Trim() + "</td>"
                                    + "    </tr> "
                                        + "     <tr>"
                                    + "       <td><b>Target Date :</b></td>"
                                    + "       <td>" + taskTargetDate.ToString().Trim() + "</td>"
                                    + "    </tr> "
                                    + "  </table>";

                        string status = Utility.EmailWithoutAttachment(to_email, "", "", "Regcompliance:Assign New Task", msg_body.ToString().Trim());
                    }
                    catch (Exception ex)
                    {
                        Utility.LogText("Error Invoking save_task_detail - Send Mail Issue for this user " + taskUserEmail + ex);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Invoking save_task_detail - Send Mail Issue " + ex);
            }       
            return strReturn;
        }
        
        public static SqlConnection Connect()
        {
            SqlConnection con = null;
            try
            {
                Utility.LogText("Connect-DB Connection opening");
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegComplianceEntities"].ToString());
                con.Open();
                Utility.LogText("Connect-DB Connection opened");
            }
            catch (Exception e)
            {
                Utility.LogText("Connect-Error opening DB Connection " + e);
                throw e;
            }
            return con;
        }

        public static DataTable SelectDataInDataTable(string qry)
        {
           
            DataTable dt = new DataTable();
            SqlCommand cmd;
            SqlDataAdapter adp;
            DataSet ds = null;
            Utility.LogText("Invoking SelectDataInDataTable");
            try
            {
                SqlConnection con = Connect();
                cmd = new SqlCommand(qry, con);
                adp = new SqlDataAdapter();
                adp.SelectCommand = cmd;
                ds = new DataSet();
                adp.Fill(ds);
                con.Close();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0];
                    Utility.LogText(string.Format("SelectDataInDataTable - Returning DataTable rowcount:{0}", ds.Tables[0].Rows.Count));
                    return dt;
                }
                else
                {
                    Utility.LogText("SelectDataInDataTable - Returning null DataTable ");
                    return null;
                }
            }
            catch (Exception e)
            {
                Utility.LogText("Error Invoking SelectDataInDataTable-" + e);
                return dt;
                throw e;
            }

        }
    }
}
