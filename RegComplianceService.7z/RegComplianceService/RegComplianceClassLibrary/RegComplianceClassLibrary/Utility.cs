﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Net.Mail;
using System.Net;

namespace RegComplianceClassLibrary
{
    public class Utility
    {
        static string FileLog = ConfigurationManager.AppSettings["LogFile"].ToString();
        static string FromEmailId = ConfigurationManager.AppSettings["GmailId"].ToString();
        static string FromPassword = ConfigurationManager.AppSettings["GmailPassword"].ToString();

        public static void SendMailViaGmail(string MsgBody, string attachedFileName, string attachedFileName2, string Subj = "RegCompliance Automated Service")//, string attachedFileName)
        {
            //bool abc = false;
            try
            {
                System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential(FromEmailId, FromPassword);
                smtp.EnableSsl = true;

                //service mail send to
                System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage(FromEmailId, "testr@xyz.com", Subj, MsgBody);
                System.Net.Mail.MailAddress bcc = new System.Net.Mail.MailAddress("testsd@xyz.com");//
                message.Bcc.Add(bcc);
                

                message.IsBodyHtml = true;
                //System.Net.Mail.Attachment attachmentSchedule = new System.Net.Mail.Attachment(attachedFileName);
                //message.Attachments.Add(attachmentSchedule);

                //System.Net.Mail.Attachment attachmentTeams = new System.Net.Mail.Attachment(attachedFileName2);
                //message.Attachments.Add(attachmentTeams);

                // abc = true;
                try
                {
                    smtp.Send(message);
                }
                catch (Exception ex)
                {
                    //abc = false;
                }
            }
            catch (Exception exc)
            {
                //abc = false;
            }
            //return abc;
        }

        public static string EmailWithoutAttachment(string to_email, string cc, string bcc, string subject, string message)
        {
            try
            {
                string HostName = "smtp.gmail.com";
                //string FromEmailId = FromEmailId;
                //string FromPassword = FromPassword;

                MailMessage mailMsg = new MailMessage();

                mailMsg.From = new MailAddress(FromEmailId);
                mailMsg.Subject = subject.ToString();
                mailMsg.Body = message.ToString();
                mailMsg.IsBodyHtml = true;

                //Add Multiple Receipent Email Ids
                string[] multiple_receipent = to_email.Split(',');
                foreach (string MultipleEmailId in multiple_receipent)
                {
                    mailMsg.To.Add(new MailAddress(MultipleEmailId));
                }
                //Add Multiple CC Email Ids
                if (cc.ToString() != "")
                {
                    string[] multiple_cc_receipent = cc.Split(',');
                    foreach (string MultipleCCEmailId in multiple_cc_receipent)
                    {
                        mailMsg.CC.Add(new MailAddress(MultipleCCEmailId));
                    }
                }
                //Add Multiple Bcc Email Ids
                if (bcc.ToString() != "")
                {
                    string[] multiple_bcc_receipent = bcc.Split(',');
                    foreach (string MultipleBCCEmailId in multiple_bcc_receipent)
                    {
                        mailMsg.Bcc.Add(new MailAddress(MultipleBCCEmailId));
                    }
                }


                //if (FileUpload2.HasFile)//Attaching document    
                //{
                //    string FileName = Path.GetFileName(FileUpload2.PostedFile.FileName);
                //    message.Attachments.Add(new Attachment(FileUpload2.PostedFile.InputStream, FileName));
                //}  

                SmtpClient smtp = new SmtpClient();

                smtp.Host = HostName;
                smtp.EnableSsl = true;
                NetworkCredential nwc = new NetworkCredential();
                nwc.UserName = mailMsg.From.Address;
                nwc.Password = FromPassword;

                smtp.UseDefaultCredentials = true;
                smtp.Credentials = nwc;
                smtp.Port = 587;

                try
                {
                    smtp.Send(mailMsg); //Send Email
                }
                catch (Exception ex)
                {
                    return "Failure";
                    throw ex;

                }
                return "Success";
            }
            catch (Exception e)
            {
                //return e.InnerException.Message.ToString();
                return "Failure";
            }

        }

        public static void SendMailToUser() { 
            //Send Mail to User and Assignee
                try
                {
                    string send_mail_query = "";
                        //" select distinct isnull((select distinct TaskMasterTaskName from TaskMaster as tskMst  join TaskDetail  as tskdtl on tskMst.TaskMasterId=tskdtl.TaskDetailTaskMasterId where tskdtl.TaskDetailTaskMasterId=" + TaskDetailTaskMasterId + "),'') as TaskMasterTaskName , "
                        //        + " isnull((select distinct UserName from Users  as usrs  join TaskDetail  as tskdtl on usrs.UserId=tskdtl.TaskDetailUserId where tskdtl.TaskDetailUserId=" + TaskDetailUserId + "),'') as UserName , "
                        //        + " isnull((select distinct UserEmail from Users as usrs  join TaskDetail  as tskdtl on usrs.UserId=tskdtl.TaskDetailUserId where tskdtl.TaskDetailUserId=" + TaskDetailUserId + "),'') as UserEmail , "
                        //        + " isnull((select distinct UserName from Users as usrs join TaskDetail  as tskdtl on  usrs.UserId=tskdtl.TaskDetailAssignee where tskdtl.TaskDetailAssignee=" + TaskDetailAssignee + "),'') as AssigneeName, "
                        //        + " isnull((select distinct UserEmail from Users as usrs join TaskDetail  as tskdtl on  usrs.UserId=tskdtl.TaskDetailAssignee where tskdtl.TaskDetailAssignee=" + TaskDetailAssignee + "),'') as AssigneeEmail, "
                        //        + " isnull((select distinct TaskMasterPriority from TaskMaster as tskMst  join TaskDetail as tskdtl on tskMst.TaskMasterId=tskdtl.TaskDetailTaskMasterId where tskdtl.TaskDetailTaskMasterId=" + TaskDetailTaskMasterId + "),'') as TaskMasterPriority , "
                        //        + " isnull((select distinct TaskMasterSchedule from TaskMaster as tskMst  join TaskDetail as tskdtl on tskMst.TaskMasterId=tskdtl.TaskDetailTaskMasterId where tskdtl.TaskDetailTaskMasterId=" + TaskDetailTaskMasterId + "),'') as TaskMasterSchedule , "
                        //        + " isnull((select distinct convert(varchar(10),TaskMasterTargetDate,103) from TaskMaster as tskMst  join TaskDetail  as tskdtl on tskMst.TaskMasterId=tskdtl.TaskDetailTaskMasterId where tskdtl.TaskDetailTaskMasterId=" + TaskDetailTaskMasterId + "),'') as TaskMasterTargetDate ";

                    DataTable dt = ConnectionDB.SelectDataInDataTable(send_mail_query);
                    string task_detail_taskname = string.Empty;
                    string task_detail_username = string.Empty, task_detail_useremail = string.Empty;
                    string task_detail_assigneename = string.Empty, task_detail_assigneeemail = string.Empty;
                    string task_detail_taskmasterpriority = string.Empty, task_detail_taskmastertargetdate = string.Empty;
                    string task_detail_taskmasterschedule = string.Empty;

                    if (dt.Rows.Count > 0)
                    {
                        for (int index = 0; index < dt.Rows.Count; index++)
                        {
                            task_detail_taskname = dt.Rows[index]["TaskMasterTaskName"].ToString();
                            task_detail_username = dt.Rows[index]["UserName"].ToString();
                            task_detail_useremail = dt.Rows[index]["UserEmail"].ToString();
                            task_detail_assigneename = dt.Rows[index]["AssigneeName"].ToString();
                            task_detail_assigneeemail = dt.Rows[index]["AssigneeEmail"].ToString();
                            task_detail_taskmasterpriority = dt.Rows[index]["TaskMasterPriority"].ToString();
                            task_detail_taskmasterschedule = dt.Rows[index]["TaskMasterSchedule"].ToString();
                            task_detail_taskmastertargetdate = dt.Rows[index]["TaskMasterTargetDate"].ToString();

                            try
                            {
                                string to_email = string.Join(",", task_detail_useremail, task_detail_assigneeemail);

                                string msg_body = "<b>Hello,</b><br/>"
                                            + "Task Name         : " + task_detail_taskname.ToString().Trim() + " <br/>"
                                            + "Task Assign To    : " + task_detail_username.ToString().Trim() + " <br/>"
                                            + "Supervisor        : " + task_detail_assigneename.ToString().Trim() + " <br/>"
                                            + "Priority          : " + task_detail_taskmasterpriority.ToString().Trim() + " <br/>"
                                            + "Schedule          : " + task_detail_taskmasterschedule.ToString().Trim() + " <br/>"
                                            + "Target Date       : " + task_detail_taskmastertargetdate.ToString().Trim() + " <br/>";

                                string status = EmailWithoutAttachment(to_email, "", "", "Regcompliance:Assign New Task", msg_body.ToString().Trim());
                            }
                            catch (Exception ex)
                            {
                                LogText("Error Invoking save_task_detail - Send Mail Issue for this user " + task_detail_useremail + " by this assignee" + task_detail_assigneeemail + " ");
                            }

                        }
                    }

                }
                catch (Exception ex)
                {
                    LogText("Error Invoking save_task_detail - Send Mail Issue "+ ex);
                }            
        }

        public static void LogText(string strLog) // To Write Log
        {
            try
            {
                File.AppendAllText(FileLog + "LogRegCompliance.txt", DateTime.Now.ToString("dd/MMM/yyyy T-HH:mm:ss") + ": " + strLog + System.Environment.NewLine);
            }
            catch (Exception ex) { }
        }
    }
}
