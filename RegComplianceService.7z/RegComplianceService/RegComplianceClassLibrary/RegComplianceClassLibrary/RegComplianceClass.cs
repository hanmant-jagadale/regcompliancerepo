﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;

namespace RegComplianceClassLibrary
{
    public class RegComplianceClass
    {
        static string IsSendMail = ConfigurationManager.AppSettings["IsSendMail"].ToString();

        public static void RegCompMainFuncAllData()
        {
            try
            {
                //here is main logic goes..
                UpdateEventsDelayedStatus();

                CreateRecuringEventsToUsers();

                if (IsSendMail.ToString() == "yes")
                    Utility.SendMailViaGmail("Hi All,<br/>  RegCompliance service Executed Successfully. <br/> Successfully on time - " + DateTime.Now + " <br/><br/>", "", "");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log RegCompMainFuncAllData():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void UpdateEventsDelayedStatus()
        {
            try
            {
                //string status = update_auto_delayed_status(); //Auto Update Delayed Status
                string event_status = ConnectionDB.update_auto_delayed_status_events();//Auto Update Delayed Status Event

                Utility.LogText("Success - Update Auto Delayed Status - " + event_status);
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log UpdateEventsDelayedStatus():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void CreateRecuringEventsToUsers()
        {
            try
            {
                Utility.LogText("called CreateRecuringEventsToUsers");

                DataTable dtTaskDetail = ConnectionDB.getAllTaskDetail();

                DataTable dtHolidayDetail = ConnectionDB.getAllHolidaysDetail();

                //Weekly Events Logic
                DataTable FilterWeeklyTable = new DataTable();
                var WeeklyDataTable = dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "weekly");
                if (WeeklyDataTable.Any())
                {
                    FilterWeeklyTable = WeeklyDataTable.CopyToDataTable();
                }
                
                if (FilterWeeklyTable!=null && FilterWeeklyTable.Rows.Count > 0)
                {
                    weeklyCreateEventsToUser(FilterWeeklyTable, dtHolidayDetail);
                }
                else
                {
                    Utility.LogText("FilterWeeklyTable getting row count -" + FilterWeeklyTable.Rows.Count); 
                }

                //Daily Events Logic
                DataTable FilterDailyTable = new DataTable();
                var DailyDataTable = dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "daily");
                if (DailyDataTable.Any())
                {
                    FilterDailyTable = DailyDataTable.CopyToDataTable();
                }
                
                if (FilterDailyTable!=null && FilterDailyTable.Rows.Count > 0)
                {
                    dailyCreateEventsToUser(FilterDailyTable, dtHolidayDetail);
                }
                else
                {
                    Utility.LogText("FilterDailyTable getting row count -" + FilterDailyTable.Rows.Count);
                }

                //FortNight Events Logic
                DataTable FilterFourtNightTable = new DataTable();
                var FourtNightDataTable = dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "fortnight");
                if (FourtNightDataTable.Any())
                {
                    FilterFourtNightTable = FourtNightDataTable.CopyToDataTable();
                }
                if (FilterFourtNightTable != null && FilterFourtNightTable.Rows.Count > 0)
                {
                    fortNightCreateEventsToUser(FilterFourtNightTable, dtHolidayDetail);
                }
                else
                {
                    Utility.LogText("FilterFourtNightTable getting row count -" + FilterFourtNightTable.Rows.Count);
                }

                //monthly Events Logic
                DataTable FilterMonthlyTable = new DataTable();
                var MonthlyDataTable = dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "monthly");
                if (MonthlyDataTable.Any())
                {
                    FilterMonthlyTable = MonthlyDataTable.CopyToDataTable();
                }
                if (FilterMonthlyTable!=null && FilterMonthlyTable.Rows.Count > 0)
                {
                    monthlyCreateEventsToUser(FilterMonthlyTable, dtHolidayDetail);
                }
                else
                {
                    Utility.LogText("FilterMonthlyTable getting row count -" + FilterMonthlyTable.Rows.Count);
                }

                //Quaterly Events Logic
                DataTable FilterQuaterlyTable=new DataTable();
                var firstDataTable=dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "quaterly");
               // DataTable FilterQuaterlyTable = dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "quaterly");
                if(firstDataTable.Any()){
                    FilterQuaterlyTable = firstDataTable.CopyToDataTable();
                }
                    
                if (FilterQuaterlyTable != null && FilterQuaterlyTable.Rows.Count > 0)
                {
                    quaterlyCreateEventsToUser(FilterQuaterlyTable, dtHolidayDetail);
                }                
                else
                {
                    Utility.LogText("FilterQuaterlyTable getting row count -" + FilterQuaterlyTable.Rows.Count);
                }

               
                //HalfYearly Events Logic
                DataTable FilterHalfYearTable = new DataTable();
                var HalfYearDataTable = dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "halfyearly");
                if (HalfYearDataTable.Any())
                {
                    FilterHalfYearTable = HalfYearDataTable.CopyToDataTable();
                }
                if (FilterHalfYearTable != null && FilterHalfYearTable.Rows.Count > 0)
                {
                    halfYearCreateEventsToUser(FilterHalfYearTable, dtHolidayDetail);
                }
                else
                {
                    Utility.LogText("FilterHalfYearTable getting row count -" + FilterHalfYearTable.Rows.Count);
                }

                //Yearly Events Logic      
                DataTable FilterYearlyTable = new DataTable();
                var YearlyDataTable = dtTaskDetail.AsEnumerable().Where(r => r.Field<string>("TaskMasterSchedule").ToString().ToLower() == "yearly");
                if (YearlyDataTable.Any())
                {
                    FilterYearlyTable = YearlyDataTable.CopyToDataTable();
                }
                if (FilterYearlyTable != null && FilterYearlyTable.Rows.Count > 0)
                {
                    yearlyCreateEventsToUser(FilterYearlyTable, dtHolidayDetail);
                }
                else
                {
                    Utility.LogText("FilterYearlyTable getting row count -" + FilterYearlyTable.Rows.Count);
                }

                Utility.LogText("Success - Update Auto Delayed Status - ");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log CreateRecuringEventsToUsers():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void weeklyCreateEventsToUser(DataTable dtTaskDetail, DataTable dtHolidayDetail) 
        {
            try
            {
                Utility.LogText("called weeklyCreateEventsToUser ");

                for (int i = 0; i < dtTaskDetail.Rows.Count; i++)
                {
                    if (dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString() != "")
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday=DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-7);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddDays(7), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);                            
                        }
                    }
                    else
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskMasterTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-7);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddDays(7), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {                                
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {                                    
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);                            
                        }
                    }
                }
                Utility.LogText("Success weeklyCreateEventsToUser ");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log in sweeklyCreateEventsToUser():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void dailyCreateEventsToUser(DataTable dtTaskDetail, DataTable dtHolidayDetail)
        {
            try
            {
                Utility.LogText("called dailyCreateEventsToUser");

                for (int i = 0; i < dtTaskDetail.Rows.Count; i++)
                {
                    if (dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString() != "")//15/07/2016 getting date from taskDetail Table
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-1).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-7);
                                                       
                            // Create Event in EventDetail..
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget, dtTaskDetail.Rows[i]);
                                                        
                            // Update targetDate in taskDetail..
                            if (dtTarget.AddDays(1).DayOfWeek.ToString() == "Saturday")
                            {
                                int daycount = 3;
                                for (int j = 3; j < 8; j++)
                                {
                                    if (dateExistInHolidays(dateTarget.AddDays(j), dtHolidayDetail))
                                    {
                                        daycount++;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                ConnectionDB.updateTaskDetail(dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]["TaskDetailId"].ToString()); 
                                //ConnectionDB.updateTaskDetail(dateTarget.AddDays(2), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());
                            }                            
                            else
                            {                                
                                //int days = 1;
                                int daycount=1;
                                for (int j = 1; j < 8; j++)
                                {
                                    if (dateExistInHolidays(dateTarget.AddDays(j), dtHolidayDetail))
                                    {
                                        daycount++;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                ConnectionDB.updateTaskDetail(dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());                                
                            }
                        }
                    }
                    else//15/07/2016 getting date from taskMaster Table
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskMasterTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-1).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-1);


                            // Create Event in EventDetail..
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget, dtTaskDetail.Rows[i]);

                            // Update targetDate in taskDetail..
                            if (dtTarget.AddDays(1).DayOfWeek.ToString() == "Saturday")
                            {
                                int daycount = 3;
                                for (int j = 3; j < 8; j++)
                                {
                                    if (dateExistInHolidays(dateTarget.AddDays(j), dtHolidayDetail))
                                    {
                                        daycount++;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                ConnectionDB.updateTaskDetail(dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]["TaskDetailId"].ToString()); 
                                //ConnectionDB.updateTaskDetail(dateTarget.AddDays(2), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());
                            }                            
                            else
                            {
                                int daycount = 1;
                                for (int j = 1; j < 8; j++)
                                {
                                    if (dateExistInHolidays(dateTarget.AddDays(j), dtHolidayDetail))
                                    {
                                        daycount++;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                ConnectionDB.updateTaskDetail(dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());
                                //ConnectionDB.updateTaskDetail(dateTarget.AddDays(1), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());                                
                            }                            
                        }
                    }
                }
                Utility.LogText("Success dailyCreateEventsToUser");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log in dailyCreateEventsToUser():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void fortNightCreateEventsToUser(DataTable dtTaskDetail, DataTable dtHolidayDetail)
        {
            try
            {
                Utility.LogText("called fortNightCreateEventsToUser");

                for (int i = 0; i < dtTaskDetail.Rows.Count; i++)
                {
                    if (dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString() != "")
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-7);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddDays(14), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                    else
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskMasterTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-14);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddDays(14), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                }
                Utility.LogText("Success fortNightCreateEventsToUser ");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log in fortNightCreateEventsToUser():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void monthlyCreateEventsToUser(DataTable dtTaskDetail, DataTable dtHolidayDetail)
        {
            try
            {
                Utility.LogText("called monthlyCreateEventsToUser");

                for (int i = 0; i < dtTaskDetail.Rows.Count; i++)
                {
                    if (dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString() != "")
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddMonths(1);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddMonths(1), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                    else
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskMasterTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddMonths(1);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddMonths(1), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                }
                Utility.LogText("Success monthlyCreateEventsToUser");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log in monthlyCreateEventsToUser():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void quaterlyCreateEventsToUser(DataTable dtTaskDetail, DataTable dtHolidayDetail)
        {
            try
            {
                Utility.LogText("called quaterlyCreateEventsToUser");

                for (int i = 0; i < dtTaskDetail.Rows.Count; i++)
                {
                    if (dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString() != "")
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-7);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddMonths(4), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                    else
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskMasterTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-14);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddMonths(4), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                }
                Utility.LogText("Success quaterlyCreateEventsToUser");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log in quaterlyCreateEventsToUser():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void halfYearCreateEventsToUser(DataTable dtTaskDetail, DataTable dtHolidayDetail)
        {
            try
            {
                Utility.LogText("called halfYearCreateEventsToUser");

                for (int i = 0; i < dtTaskDetail.Rows.Count; i++)
                {
                    if (dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString() != "")
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-7);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddMonths(6), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                    else
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskMasterTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-14);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddMonths(6), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                }
                Utility.LogText("Success halfYearCreateEventsToUser");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log in halfYearCreateEventsToUser():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static void yearlyCreateEventsToUser(DataTable dtTaskDetail, DataTable dtHolidayDetail)
        {
            try
            {
                Utility.LogText("called yearlyCreateEventsToUser");

                for (int i = 0; i < dtTaskDetail.Rows.Count; i++)
                {
                    if (dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString() != "")
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskDetailTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-7);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddYears(1), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                    else
                    {
                        DateTime dtTarget = DateTime.ParseExact(dtTaskDetail.Rows[i]["TaskMasterTargetDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        DateTime dateToday = DateTime.UtcNow.AddHours(5).AddMinutes(30);

                        if (dtTarget.AddDays(-3).Date == dateToday.Date)
                        {
                            DateTime dateTarget = dtTarget;
                            DateTime dateStart = dtTarget.AddDays(-14);

                            // update targetDate in taskDetail..
                            ConnectionDB.updateTaskDetail(dateTarget.AddYears(1), dtTaskDetail.Rows[i]["TaskDetailId"].ToString());

                            // Create Event in EventDetail..
                            int daycount = 0;
                            for (int j = 0; j > -7; j--)
                            {
                                if (dateExistInHolidays(dateTarget.AddDays(daycount), dtHolidayDetail))
                                {
                                    daycount--;
                                }
                                if (dateTarget.AddDays(daycount).DayOfWeek.ToString() == "Sunday")
                                {
                                    daycount = daycount - 2;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            ConnectionDB.createEventToUser(dtTaskDetail.Rows[i]["TaskDetailId"].ToString(), dtTaskDetail.Rows[i]["TaskDetailUserId"].ToString(), dateTarget.AddDays(daycount), dtTaskDetail.Rows[i]);
                        }
                    }
                }
                Utility.LogText("Success yearlyCreateEventsToUser");
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log in yearlyCreateEventsToUser():" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
        }

        public static bool dateExistInHolidays(DateTime dtTargetDate, DataTable dtHolidayDetail) 
        {
            bool retValidate = false;
            try
            {
                if (dtHolidayDetail != null && dtHolidayDetail.Rows.Count > 0)
                {
                    for (int i = 0; i < dtHolidayDetail.Rows.Count; i++)
                    {
                        DateTime dtHoliday = DateTime.ParseExact(dtHolidayDetail.Rows[i]["HolidayDate"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);

                        if (dtTargetDate.Date == dtHoliday.Date)
                        {
                            retValidate = true;
                        }
                    }
                }
            }
            catch (Exception ex) {
                Utility.LogText("Error in dateExistInHolidays " + ex);
            }
            return retValidate;
        }
    }
}
