﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Configuration;

using RegComplianceClassLibrary;

namespace RegComplianceWindowsService
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        System.Timers.Timer timerVal = new System.Timers.Timer();
        TimeSpan time = new TimeSpan(Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["timerHour"].ToString()), Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["timerMinutes"].ToString()), 0);
        protected override void OnStart(string[] args)
        {
            timerVal.Enabled = true;
            timerVal.Interval = 1000 * 60 * (Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["ServiceIntervalInSecond"].ToString())); //Time set on Config           
            timerVal.AutoReset = true;
            timerVal.Elapsed += new System.Timers.ElapsedEventHandler(timer_Ticked);                   
            
            Utility.LogText("RegCompliance service started. Messages time- " + DateTime.Now);
            RegComplianceClass.RegCompMainFuncAllData();
            Utility.SendMailViaGmail("Hi All,<br/> RegCompliance service started Successfully. <br/><br/>", "", "", "RegCompliance Service Started");   
        }

        private void timer_Ticked(object sender, System.Timers.ElapsedEventArgs e)
        {
            timerVal.Stop();
            timerVal.Enabled = false;
            try
            {
                DateTime today = DateTime.Now.AddSeconds(-15);//DateTime.Now.ToString("HH:mm:ss")
                if (today.TimeOfDay.Hours == time.Hours && today.TimeOfDay.Minutes == time.Minutes)
                {
                    RegComplianceClass.RegCompMainFuncAllData();
                }
            }
            catch (Exception ex)
            {
                Utility.LogText("Error Log timer_Ticked:" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine);
            }
            timerVal.Start();
            timerVal.Enabled = true;
        }

        protected override void OnStop()
        {
            try
            {
                timerVal.Stop();
                timerVal.Enabled = false;
                Utility.SendMailViaGmail("Hi All,<br/> RegCompliance service has been stopped! <br/> Please check on priority!!!<br/>", "", "", "RegCompliance Service Stopped");
                Utility.LogText("RegCompliance service service stop. Messages time- " + DateTime.Now);
            }
            catch (Exception ex) { Utility.LogText("Error Log OnStop:" + ex.Message + System.Environment.NewLine + "------------------////----------------" + System.Environment.NewLine); }
        }
    }
}
